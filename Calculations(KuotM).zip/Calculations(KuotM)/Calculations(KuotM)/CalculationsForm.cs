﻿/*
 * Created by: Kuot Mariak
 * Created on: 13-09-2018
 * Created for: ICS3U Programming
 * Daily Assignment – Day #5 - Name of Program
 * Calculations...
*/
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Calculations_KuotM_
{
    public partial class CalculationsForm : Form
    {
        public CalculationsForm()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }
}
